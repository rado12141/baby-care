<?php
	define("DB_HOST", "localhost");
	define("DB_USER", "root");
	define("DB_PASS", "");
	define("DB_NAME", "db_babycare");
	define("TITLE", "Online BabyCare Service");
	define("KEYWORDS", "Babycare, Infant of Baby, Nutriotious Food for baby, Healthy Food for baby,
			Suggestion about baby's growth, doctors helpline, hospital collection of bangladesh,
			doctors information of bangladesh");
?>