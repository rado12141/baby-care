	<!--Header: site header with title, description & meta content-->
<?php include 'inc/header.php'; ?>

<!--MENU: navigation bar-->
<?php include 'inc/menu.php'; ?>


	<!-- Projects Section -->
	
	<div class="container pt">
		<div class="row mt centered">

			<div class="col-lg-9">

			</div>

			<div class="col-lg-3" style="text-align:left; border-left:1px solid #000;">
				<h4>Recent</h4><hr/>
				<p style="max-height:550px; overflow:scroll;">
					<a href="about.php">1 Year Children..</a><br/>
				    <a href="about.php">1 Year Children..</a><br/>
					<a href="about.php">1 Year Children..</a><br/>
					<a href="about.php">1 Year Children..</a><br/>
					<a href="about.php">1 Year Children..</a><br/>
				</p>
			</div>

		</div><!-- /row -->

	</div><!-- /container -->
	


<!--Footer: footer navigation & social link -->
<?php include 'inc/footer.php'; ?>
