	<!-- Projects Section -->
	
	<div class="container pt">
		<div class="row mt centered">	

			<h3>Diseses <img class="" src="assets/img/sublogo.jpg" alt="sl" style="margin:0px 10px;"/>  Menu 2</h3><hr/>

			<div class="col-lg-2">
				<p><a class="green" href="page.php">Menu 1 about diseses</a></p>
				</p><a class="green currentmenu" href="page1.php">Menu 2</a></p>
				</p><a class="green" href="page.php">Menu 3</a></p>
				</p><a class="green" href="#">Menu 4</a></p>
			</div>
			<div class="col-lg-10">	
				<div class="row">
					<div class="centered">
						<p style="text-align:justify; padding:5px;">
							It is a long established fact that a reader will be distracted by the readable content of a page when 
							It is a long established fact that a reader will be distracted by the readable content of a page when 
							It is a long established fact that a reader will be distracted by the readable content of a page when 
							It is a long established fact that a reader will be distracted by the readable content of a page when 
							It is a long established fact that a reader will be distracted by the readable content of a page when 
							It is a long established fact that a reader will be distracted by the readable content of a page when 
							It is a long established fact that a reader will be distracted by the readable content of a page when 
							It is a long established fact that a reader will be distracted by the readable content of a page when 
							<br/>
							<img class="img-responsive" src="assets/img/portfolio/port01.jpg" alt="" style="margin:5px auto;"/>
							It is a long established fact that a reader will be distracted by the readable content of a page when 
							It is a long established fact that a reader will be distracted by the readable content of a page when 
							It is a long established fact that a reader will be distracted by the readable content of a page when 
							It is a long established fact that a reader will be distracted by the readable content of a page when 
							It is a long established fact that a reader will be distracted by the readable content of a page when 
							<br/>
							
						</p>
					</div>
				</div>
			</div>
		</div><!-- /row -->
	</div><!-- /container -->



 

